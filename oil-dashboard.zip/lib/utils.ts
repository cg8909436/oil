import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Utilidades para formateo de datos
export function formatCurrency(value: number, currency = "USD"): string {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 2,
  }).format(value)
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("es-AR").format(value)
}

export function formatPercentage(value: number): string {
  return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`
}

// Utilidad para generar colores aleatorios para gráficos
export function generateChartColors(count: number): string[] {
  const colors = [
    "#8B5CF6",
    "#A78BFA",
    "#C4B5FD",
    "#DDD6FE",
    "#EC4899",
    "#F472B6",
    "#F9A8D4",
    "#FBCFE8",
    "#06B6D4",
    "#67E8F9",
    "#A5F3FC",
    "#CFFAFE",
    "#10B981",
    "#6EE7B7",
    "#A7F3D0",
    "#D1FAE5",
  ]
  return colors.slice(0, count)
}
