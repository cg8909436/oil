# 🚀 Dashboard Energético Argentina

Dashboard interactivo del mercado petrolero argentino con análisis en tiempo real.

## 🚀 Instalación Rápida

\`\`\`bash
# 1. Instalar dependencias
npm install

# 2. Ejecutar en desarrollo
npm run dev

# 3. Abrir http://localhost:3000
\`\`\`

## ✨ Características

- 📊 5 secciones completas de análisis
- 🏢 Información detallada de 6 empresas argentinas
- 📱 Diseño completamente responsivo
- 🎨 Interfaz moderna con gradientes púrpura/rosa
- 📈 Gráficos interactivos con Recharts

## 🛠️ Tecnologías

- Next.js 14 + React 18 + TypeScript
- Tailwind CSS + shadcn/ui
- Recharts + Lucide React

## 🚀 Instalación y Uso

### Prerrequisitos
- Node.js 18+ 
- npm o yarn

### Instalación

1. **Clona el repositorio**
\`\`\`bash
git clone https://github.com/tu-usuario/oil-dashboard-argentina.git
cd oil-dashboard-argentina
\`\`\`

2. **Instala las dependencias**
\`\`\`bash
npm install
# o
yarn install
\`\`\`

3. **Ejecuta el servidor de desarrollo**
\`\`\`bash
npm run dev
# o
yarn dev
\`\`\`

4. **Abre tu navegador**
Visita [http://localhost:3000](http://localhost:3000) para ver la aplicación.

## 📁 Estructura del Proyecto

\`\`\`
oil-dashboard-argentina/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   └── ui/
│       ├── badge.tsx
│       ├── button.tsx
│       ├── card.tsx
│       ├── dialog.tsx
│       ├── input.tsx
│       └── select.tsx
├── lib/
│   └── utils.ts
├── public/
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── README.md
\`\`\`

## 🏢 Empresas Incluidas

### **YPF S.A.**
- Líder nacional en exploración y producción
- Operaciones principales en Vaca Muerta
- 19,000 empleados, fundada en 1922

### **Pampa Energía**
- Empresa integrada de energía
- Generación eléctrica y E&P
- 3,200 empleados, fundada en 2005

### **Vista Oil & Gas**
- Especialista en recursos no convencionales
- Enfoque en shale oil/gas
- 850 empleados, fundada en 2017

### **Tecpetrol**
- Subsidiaria del Grupo Techint
- Pionera en desarrollo no convencional
- 2,100 empleados, fundada en 1946

### **CGC (Compañía General de Combustibles)**
- Distribución de gas natural
- Generación eléctrica
- 4,500 empleados, fundada en 1992

### **Capex S.A.**
- Servicios petroleros integrales
- Perforación y completación
- 1,800 empleados, fundada en 1978

## 📊 Secciones del Dashboard

### 1. **Resumen General**
- KPIs principales del sector
- Noticias relevantes
- Indicadores de mercado

### 2. **Cotizaciones**
- Precios internacionales actualizados
- Comparación de diferentes tipos de crudo
- Tendencias y variaciones

### 3. **Análisis**
- Gráficos interactivos personalizables
- Múltiples tipos de visualización
- Filtros por período de tiempo

### 4. **Empresas**
- Información detallada de cada compañía
- Datos financieros y operacionales
- Sistema de búsqueda avanzado

### 5. **Producción**
- Análisis por regiones argentinas
- Datos de producción y crecimiento
- Visualización geográfica

## 🎯 Características Técnicas

### **Performance**
- Renderizado del lado del servidor (SSR)
- Optimización automática de imágenes
- Lazy loading de componentes

### **Accesibilidad**
- Cumple con estándares WCAG 2.1
- Navegación por teclado
- Lectores de pantalla compatibles

### **Responsividad**
- Mobile-first design
- Breakpoints optimizados
- Touch-friendly interfaces

## 🔧 Scripts Disponibles

\`\`\`bash
# Desarrollo
npm run dev

# Construcción para producción
npm run build

# Iniciar servidor de producción
npm run start

# Linting
npm run lint

# Verificación de tipos
npm run type-check
\`\`\`

## 🌟 Próximas Características

- [ ] Integración con APIs reales de precios
- [ ] Sistema de alertas y notificaciones
- [ ] Comparador de empresas
- [ ] Mapas interactivos de operaciones
- [ ] Exportación de datos (PDF/CSV)
- [ ] Modo oscuro/claro
- [ ] Dashboard personalizable

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

MIT License
\`\`\`

## 👨‍💻 Autor

**Tu Nombre**
- GitHub: [@tu-usuario](https://github.com/tu-usuario)
- LinkedIn: [Tu Perfil](https://linkedin.com/in/tu-perfil)
- Email: tu.email@ejemplo.com

## 🙏 Agradecimientos

- [Next.js](https://nextjs.org/) por el framework
- [Tailwind CSS](https://tailwindcss.com/) por los estilos
- [shadcn/ui](https://ui.shadcn.com/) por los componentes
- [Recharts](https://recharts.org/) por las visualizaciones
- [Lucide](https://lucide.dev/) por los iconos

---

⭐ Si te gusta este proyecto, ¡dale una estrella en GitHub!
