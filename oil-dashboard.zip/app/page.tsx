"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"
import {
  TrendingUp,
  TrendingDown,
  Search,
  Building2,
  BarChart3,
  DollarSign,
  Activity,
  Globe,
  MapPin,
  Users,
  Calendar,
  Zap,
  Fuel,
  Factory,
  Info,
  Star,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"

const chartData = [
  { month: "Ene", price: 75, volume: 120, volatility: 2.1 },
  { month: "Feb", price: 78, volume: 135, volatility: 1.8 },
  { month: "Mar", price: 80, volume: 142, volatility: 2.3 },
  { month: "Abr", price: 77, volume: 128, volatility: 2.7 },
  { month: "May", price: 85, volume: 156, volatility: 1.9 },
  { month: "Jun", price: 88, volume: 168, volatility: 2.2 },
]

const sectorData = [
  { name: "Exploración", value: 35, color: "#8B5CF6" },
  { name: "Refinación", value: 28, color: "#A78BFA" },
  { name: "Distribución", value: 22, color: "#C4B5FD" },
  { name: "Servicios", value: 15, color: "#DDD6FE" },
]

const productionData = [
  { region: "Vaca Muerta", production: 450, growth: 12.5 },
  { region: "Golfo San Jorge", production: 280, growth: -2.1 },
  { region: "Cuenca Neuquina", production: 320, growth: 8.3 },
  { region: "Cuenca Austral", production: 180, growth: 4.7 },
]

const companies = [
  {
    name: "YPF",
    symbol: "YPFD",
    price: 12.45,
    change: 2.3,
    sector: "Petróleo",
    marketCap: "8.2B",
    volume: "2.1M",
    description:
      "YPF S.A. es la empresa energética más grande de Argentina. Opera en toda la cadena de valor del petróleo y gas, desde la exploración y producción hasta la refinación y comercialización.",
    operations:
      "Líder en exploración en Vaca Muerta, opera 15 refinerías y más de 1,500 estaciones de servicio en Argentina. Produce 450,000 barriles de petróleo equivalente por día.",
    founded: "1922",
    employees: "19,000",
    headquarters: "Buenos Aires, Argentina",
    rating: 4.2,
  },
  {
    name: "Pampa Energía",
    symbol: "PAM",
    price: 28.9,
    change: -1.2,
    sector: "Energía",
    marketCap: "3.1B",
    volume: "890K",
    description:
      "Pampa Energía es una empresa integrada de energía que opera en generación eléctrica, exploración y producción de petróleo y gas.",
    operations:
      "Genera 4,500 MW de energía eléctrica y produce 45,000 barriles de petróleo equivalente por día. Tiene operaciones en 8 provincias argentinas.",
    founded: "2005",
    employees: "3,200",
    headquarters: "Buenos Aires, Argentina",
    rating: 3.8,
  },
  {
    name: "Vista Oil & Gas",
    symbol: "VIST",
    price: 8.75,
    change: 4.1,
    sector: "Gas",
    marketCap: "1.8B",
    volume: "1.2M",
    description:
      "Vista Oil & Gas es una empresa independiente de exploración y producción enfocada en recursos no convencionales en Vaca Muerta.",
    operations:
      "Especializada en fracking y extracción de shale oil/gas. Opera 180 pozos activos en Vaca Muerta con producción de 85,000 boe/d.",
    founded: "2017",
    employees: "850",
    headquarters: "Buenos Aires, Argentina",
    rating: 4.0,
  },
  {
    name: "Tecpetrol",
    symbol: "TEC",
    price: 15.6,
    change: 1.8,
    sector: "Petróleo",
    marketCap: "2.4B",
    volume: "650K",
    description:
      "Tecpetrol es una empresa argentina de exploración y producción de hidrocarburos, subsidiaria del Grupo Techint.",
    operations:
      "Produce 120,000 boe/d principalmente en Vaca Muerta y Fortín de Piedra. Pionera en desarrollo de recursos no convencionales en Argentina.",
    founded: "1946",
    employees: "2,100",
    headquarters: "Buenos Aires, Argentina",
    rating: 3.9,
  },
  {
    name: "CGC",
    symbol: "CGC",
    price: 22.3,
    change: -0.5,
    sector: "Gas",
    marketCap: "1.2B",
    volume: "420K",
    description:
      "Compañía General de Combustibles es una empresa integrada de energía con foco en gas natural y generación eléctrica.",
    operations:
      "Distribuye gas natural a 2.8 millones de usuarios y genera 1,200 MW de energía eléctrica. Opera gasoductos de 3,500 km de extensión.",
    founded: "1992",
    employees: "4,500",
    headquarters: "Buenos Aires, Argentina",
    rating: 3.7,
  },
  {
    name: "Capex",
    symbol: "CAPX",
    price: 6.8,
    change: 3.2,
    sector: "Servicios",
    marketCap: "890M",
    volume: "780K",
    description:
      "Capex S.A. es una empresa de servicios petroleros que brinda soluciones integrales para la industria de hidrocarburos.",
    operations:
      "Presta servicios de perforación, completación y workover. Opera 45 equipos de perforación y ha completado más de 800 pozos en Vaca Muerta.",
    founded: "1978",
    employees: "1,800",
    headquarters: "Neuquén, Argentina",
    rating: 3.6,
  },
]

const newsData = [
  { title: "YPF anuncia nueva inversión en Vaca Muerta", time: "Hace 2 horas", impact: "positive" },
  { title: "Precio del petróleo alcanza máximos del año", time: "Hace 4 horas", impact: "positive" },
  { title: "Nuevas regulaciones ambientales en discusión", time: "Hace 6 horas", impact: "neutral" },
  { title: "Vista Oil reporta producción récord", time: "Hace 8 horas", impact: "positive" },
]

export default function OilDashboard() {
  const [activeSection, setActiveSection] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCompany, setSelectedCompany] = useState<(typeof companies)[0] | null>(null)
  const [chartType, setChartType] = useState("line")
  const [timeRange, setTimeRange] = useState("6m")

  const filteredCompanies = companies.filter(
    (company) =>
      company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      company.symbol.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const sections = [
    { id: "overview", label: "Resumen", icon: Activity },
    { id: "cotizaciones", label: "Cotizaciones", icon: DollarSign },
    { id: "graficos", label: "Análisis", icon: BarChart3 },
    { id: "empresas", label: "Empresas", icon: Building2 },
    { id: "produccion", label: "Producción", icon: Factory },
  ]

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < Math.floor(rating) ? "text-yellow-400 fill-current" : "text-gray-400"}`}
      />
    ))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-4 md:p-6">
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
          ⚡ Dashboard Energético
        </h1>
        <p className="text-xl text-gray-300">Mercado Petrolero Argentino - Análisis en Tiempo Real</p>
      </header>

      {/* Navigation */}
      <nav className="flex flex-wrap justify-center gap-2 mb-8">
        {sections.map((section) => {
          const Icon = section.icon
          return (
            <Button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              variant={activeSection === section.id ? "default" : "secondary"}
              className={`flex items-center gap-2 transition-all duration-300 ${
                activeSection === section.id
                  ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/25"
                  : "bg-slate-700 text-gray-300 hover:bg-slate-600"
              }`}
            >
              <Icon className="w-4 h-4" />
              {section.label}
            </Button>
          )
        })}
      </nav>

      {/* Overview Section */}
      {activeSection === "overview" && (
        <section className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-br from-purple-800/50 to-slate-800/50 border-purple-500/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-300 text-sm">Precio WTI</p>
                    <p className="text-2xl font-bold">$88.00</p>
                    <div className="flex items-center gap-1 text-green-400">
                      <ArrowUpRight className="w-4 h-4" />
                      <span className="text-sm">+2.3%</span>
                    </div>
                  </div>
                  <Fuel className="w-8 h-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-pink-800/50 to-slate-800/50 border-pink-500/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-pink-300 text-sm">Producción Nacional</p>
                    <p className="text-2xl font-bold">1.2M</p>
                    <div className="flex items-center gap-1 text-green-400">
                      <ArrowUpRight className="w-4 h-4" />
                      <span className="text-sm">+8.1%</span>
                    </div>
                  </div>
                  <Factory className="w-8 h-8 text-pink-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-800/50 to-slate-800/50 border-blue-500/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-300 text-sm">Empresas Activas</p>
                    <p className="text-2xl font-bold">156</p>
                    <div className="flex items-center gap-1 text-green-400">
                      <ArrowUpRight className="w-4 h-4" />
                      <span className="text-sm">+12</span>
                    </div>
                  </div>
                  <Building2 className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-800/50 to-slate-800/50 border-green-500/20 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-300 text-sm">Inversión 2025</p>
                    <p className="text-2xl font-bold">$8.5B</p>
                    <div className="flex items-center gap-1 text-green-400">
                      <ArrowUpRight className="w-4 h-4" />
                      <span className="text-sm">+15.2%</span>
                    </div>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* News Section */}
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Noticias del Sector
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {newsData.map((news, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          news.impact === "positive"
                            ? "bg-green-400"
                            : news.impact === "negative"
                              ? "bg-red-400"
                              : "bg-yellow-400"
                        }`}
                      />
                      <div>
                        <p className="text-white font-medium">{news.title}</p>
                        <p className="text-gray-400 text-sm">{news.time}</p>
                      </div>
                    </div>
                    <Info className="w-4 h-4 text-gray-400" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Cotizaciones Section */}
      {activeSection === "cotizaciones" && (
        <section className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-400 text-xl">Precios Internacionales</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-xl">
                  <h3 className="text-purple-300 text-lg mb-2">Brent</h3>
                  <div className="text-4xl font-bold text-white mb-2">$89.45</div>
                  <div className="flex items-center justify-center gap-1 text-green-400">
                    <TrendingUp className="w-4 h-4" />
                    <span>+1.8%</span>
                  </div>
                </div>

                <div className="text-center p-6 bg-gradient-to-br from-pink-600/20 to-purple-600/20 rounded-xl">
                  <h3 className="text-pink-300 text-lg mb-2">WTI</h3>
                  <div className="text-4xl font-bold text-white mb-2">$86.20</div>
                  <div className="flex items-center justify-center gap-1 text-red-400">
                    <TrendingDown className="w-4 h-4" />
                    <span>-0.5%</span>
                  </div>
                </div>

                <div className="text-center p-6 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-xl">
                  <h3 className="text-blue-300 text-lg mb-2">Gas Natural</h3>
                  <div className="text-4xl font-bold text-white mb-2">$3.42</div>
                  <div className="flex items-center justify-center gap-1 text-green-400">
                    <TrendingUp className="w-4 h-4" />
                    <span>+3.1%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Gráficos Section */}
      {activeSection === "graficos" && (
        <section className="space-y-6">
          <div className="flex flex-wrap gap-4 mb-6">
            <Select value={chartType} onValueChange={setChartType}>
              <SelectTrigger className="w-48 bg-slate-700 border-slate-600">
                <SelectValue placeholder="Tipo de gráfico" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="line">Líneas</SelectItem>
                <SelectItem value="bar">Barras</SelectItem>
                <SelectItem value="area">Área</SelectItem>
              </SelectContent>
            </Select>

            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-48 bg-slate-700 border-slate-600">
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1m">1 Mes</SelectItem>
                <SelectItem value="3m">3 Meses</SelectItem>
                <SelectItem value="6m">6 Meses</SelectItem>
                <SelectItem value="1y">1 Año</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-purple-400">Evolución de Precios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    {chartType === "line" && (
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9CA3AF" fontSize={12} />
                        <YAxis stroke="#9CA3AF" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1E293B",
                            border: "1px solid #475569",
                            borderRadius: "8px",
                            color: "#F1F5F9",
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="price"
                          stroke="#8B5CF6"
                          strokeWidth={3}
                          dot={{ fill: "#8B5CF6", strokeWidth: 2, r: 6 }}
                        />
                      </LineChart>
                    )}
                    {chartType === "bar" && (
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9CA3AF" fontSize={12} />
                        <YAxis stroke="#9CA3AF" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1E293B",
                            border: "1px solid #475569",
                            borderRadius: "8px",
                            color: "#F1F5F9",
                          }}
                        />
                        <Bar dataKey="price" fill="#8B5CF6" />
                      </BarChart>
                    )}
                    {chartType === "area" && (
                      <AreaChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9CA3AF" fontSize={12} />
                        <YAxis stroke="#9CA3AF" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1E293B",
                            border: "1px solid #475569",
                            borderRadius: "8px",
                            color: "#F1F5F9",
                          }}
                        />
                        <Area type="monotone" dataKey="price" stroke="#8B5CF6" fill="url(#colorPrice)" />
                        <defs>
                          <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.1} />
                          </linearGradient>
                        </defs>
                      </AreaChart>
                    )}
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-purple-400">Distribución por Sector</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={sectorData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {sectorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Empresas Section */}
      {activeSection === "empresas" && (
        <section>
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-400 text-xl flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Empresas del Sector Energético
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Buscar empresa..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-gray-400"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredCompanies.map((company) => (
                  <Dialog key={company.symbol}>
                    <DialogTrigger asChild>
                      <Card className="bg-gradient-to-br from-slate-700/50 to-slate-800/50 border-slate-600/50 hover:border-purple-500/50 transition-all duration-300 cursor-pointer hover:shadow-lg hover:shadow-purple-500/10">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="font-bold text-white text-lg">{company.name}</h3>
                              <p className="text-sm text-gray-400">{company.symbol}</p>
                              <div className="flex items-center gap-1 mt-1">
                                {renderStars(company.rating)}
                                <span className="text-xs text-gray-400 ml-1">({company.rating})</span>
                              </div>
                            </div>
                            <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                              {company.sector}
                            </Badge>
                          </div>

                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-2xl font-bold text-white">${company.price}</span>
                              <div
                                className={`flex items-center gap-1 ${
                                  company.change >= 0 ? "text-green-400" : "text-red-400"
                                }`}
                              >
                                {company.change >= 0 ? (
                                  <ArrowUpRight className="w-4 h-4" />
                                ) : (
                                  <ArrowDownRight className="w-4 h-4" />
                                )}
                                <span className="text-sm font-medium">
                                  {company.change >= 0 ? "+" : ""}
                                  {company.change}%
                                </span>
                              </div>
                            </div>

                            <div className="flex justify-between text-sm text-gray-400">
                              <span>Cap. Mercado: {company.marketCap}</span>
                              <span>Volumen: {company.volume}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </DialogTrigger>

                    <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="text-2xl text-purple-400 flex items-center gap-2">
                          <Building2 className="w-6 h-6" />
                          {company.name}
                        </DialogTitle>
                      </DialogHeader>

                      <div className="space-y-6">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                            <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-1" />
                            <p className="text-sm text-gray-400">Precio</p>
                            <p className="font-bold">${company.price}</p>
                          </div>
                          <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                            <TrendingUp className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                            <p className="text-sm text-gray-400">Cambio</p>
                            <p className={`font-bold ${company.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                              {company.change >= 0 ? "+" : ""}
                              {company.change}%
                            </p>
                          </div>
                          <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                            <Users className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                            <p className="text-sm text-gray-400">Empleados</p>
                            <p className="font-bold">{company.employees}</p>
                          </div>
                          <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                            <Calendar className="w-6 h-6 text-yellow-400 mx-auto mb-1" />
                            <p className="text-sm text-gray-400">Fundada</p>
                            <p className="font-bold">{company.founded}</p>
                          </div>
                        </div>

                        <div>
                          <h4 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                            <Info className="w-5 h-5" />
                            Descripción
                          </h4>
                          <p className="text-gray-300 leading-relaxed">{company.description}</p>
                        </div>

                        <div>
                          <h4 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                            <MapPin className="w-5 h-5" />
                            Operaciones en Argentina
                          </h4>
                          <p className="text-gray-300 leading-relaxed">{company.operations}</p>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-slate-700">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-gray-400">{company.headquarters}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            {renderStars(company.rating)}
                            <span className="text-sm text-gray-400 ml-1">({company.rating}/5)</span>
                          </div>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                ))}
              </div>

              {filteredCompanies.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No se encontraron empresas que coincidan con la búsqueda.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      )}

      {/* Producción Section */}
      {activeSection === "produccion" && (
        <section className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-400 text-xl flex items-center gap-2">
                <Factory className="w-5 h-5" />
                Producción por Región
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80 w-full mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="region" stroke="#9CA3AF" fontSize={12} />
                    <YAxis stroke="#9CA3AF" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1E293B",
                        border: "1px solid #475569",
                        borderRadius: "8px",
                        color: "#F1F5F9",
                      }}
                    />
                    <Bar dataKey="production" fill="#8B5CF6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {productionData.map((region, index) => (
                  <Card key={index} className="bg-gradient-to-br from-slate-700/30 to-slate-800/30 border-slate-600/30">
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2">{region.region}</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Producción</span>
                          <span className="text-white font-medium">{region.production}k bbl/d</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Crecimiento</span>
                          <span className={`font-medium ${region.growth >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {region.growth >= 0 ? "+" : ""}
                            {region.growth}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Footer */}
      <footer className="text-center text-gray-400 text-sm mt-12 pt-8 border-t border-slate-700/50">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Zap className="w-4 h-4 text-purple-400" />
          <span>© 2025 Dashboard Energético Argentino</span>
        </div>
        <p>Datos simulados para demostración | Desarrollado con Next.js y React</p>
      </footer>
    </div>
  )
}
